package com.example.gimnasio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GimnasioApplicationTests {

	@Test
	void contextLoads() {
	}

}
